package com.example.danilo.sosagua;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

import static com.google.android.gms.plus.PlusOneDummyView.TAG;

public class UserInfoWindowAdapter implements GoogleMap.InfoWindowAdapter{
    LayoutInflater inflater = null;

    UserInfoWindowAdapter(LayoutInflater inflater){
        this.inflater = inflater;
    }

    @Override
    public View getInfoWindow(Marker arg0){
        return null;
    }

    @Override
    public View getInfoContents(Marker marker){
        View infoWindow = inflater.inflate(R.layout.user_info_windows, null);
        TextView title = (TextView)infoWindow.findViewById(R.id.title);
        TextView description = (TextView)infoWindow.findViewById(R.id.snippet);
        title.setText(marker.getTitle());
        description.setText(marker.getSnippet());


        
        Button btnAltera = (Button) findViewById(R.id.btnAltera);
        btnAltera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: BUTTON ALTERA CLICADO");

                Toast.makeText(MarksActivity.this, "Botao Alterar Clicado", Toast.LENGTH_SHORT).show();
            }
        });
        return(infoWindow);
    }

}
